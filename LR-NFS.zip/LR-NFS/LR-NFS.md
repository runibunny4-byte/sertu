### Топология
![[Pasted image 20251120162911.png]]
![[Pasted image 20251120163257.png]]
### Задание

#### Базовая настройка

1. Настройте имена устройств в соответствии с топологией
![[Pasted image 20251120163551.png]]
2. Настройте часовой пояс Актобе
![[Pasted image 20251120163643.png]]
3. Настройте адреса в соответствии с топологией
![[Pasted image 20251120164125.png]]
RTR1
![[Pasted image 20251120164106.png]]
Server1
![[Pasted image 20251120164848.png]]
Client1
![[Pasted image 20251120165710.png]]
#### Сетевые службы

1. Настройте Server1 для раздачи адресов по DHCP в сеть Client1
    1. Обеспечьте передачу настроек сети, домена "comp.local", DNS и NTP сервера
![[Pasted image 20251124142411.png]]
```
vi /etc/default/isc-dhcp-server
```
![[Pasted image 20251124143732.png]]

RTR1:
```
apt install isc-ghcp-relay
192.168.103.225
ens5 ens6

vi /etc/sysctl.conf
```
убрать на этом комментарий
![[Pasted image 20251127090726.png]]
`systemctl restart isc-dhcp-relay.service`


1. Настройте Server1 в качестве DNS сервера
    1. Создайте зону "comp.local"
`vi /etc/bind/named.conf.local`
![[Pasted image 20251124150542.png]]
        1. Добавьте А записи для всех устройств
        2. Добавьте CNAME запись nfs и ftp ссылающиеся на имя Server1
```
cp /etc/bind/db.local /var/lib/bind/comp.local
vi /var/lib/bind/comp.local
```
![[Pasted image 20251124150419.png]]

#### Файловые службы

1. Создайте RAID массив нулевого уровня на Server1
`mdadm --create /dev/md0 --level=0 --raid-devices=4 /dev/vd[abcd]`
`mkfs.ext4 /dev/md0`
`blkid | grep md0 >> /etc/fstab`
`mkdir /data`
    1. Обеспечьте автоматическое монтирование дискового массива в каталог `/data`
![[Pasted image 20251127092829.png]]
```
mount -a
```
![[Pasted image 20251127131211.png]]
```
lsblk
```
![[Pasted image 20251127131132.png]]
![[Pasted image 20251127131328.png]]
1. Опубликуйте каталог `/data/documents` по NFS с правами только на чтение для устройств в клиентской сети
```
mkdir /data/documents
chmod -R 755 /data/documents
apt install nfs-kernel-server -y
vi /etc/exports
```
![[Pasted image 20251127132937.png]]
`systemctl restart nfs-kernel-server`
    1. Настройте автоматическое монтирование ресурса на Client1 в каталог `/mnt/documents`
Client1:
```
mkdir /mnt/documents
vi /etc/fstab
```
![[Pasted image 20251127144548.png]]
    2. Командой `ln -s /mnt/documents /home/user/Desktop/`, обеспечьте удобный доступ к каталогу пользователю user
2. Опубликуйте каталог `/data/documents` по FTP, обеспечив права на чтение и запись для пользователя `boss` с паролем `123456`
```
apt install vsftpd
vi /etc/passwd
```
![[Pasted image 20251127151154.png]]
```
passwd boss
123456
123456
```
![[Pasted image 20251127151544.png]]